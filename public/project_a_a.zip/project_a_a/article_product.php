<?php require_once(dirname(__FILE__).'/include/config.inc.php');
$cid = empty($cid) ? 5 : intval($cid);
$nid = empty($nid) ? 5 : intval($nid);
 ?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="X-UA-Compatible" content="IE=Edge,chrome=1" />
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>某某医疗有限公司</title>
<meta content="网站关键字" name="keywords" />
<meta content="网站描述" name="description" />
<script type="text/javascript" src="global.js"></script>
</head>
<body>
    <!-- 公用头部 start -->
    <!-- 导航 start -->
 <?php require_once('header.php'); ?>

	<!-- banner end -->
	<!-- 公用头部 end -->
        
    <!-- 供应产品 start -->
    <!-- 供应产品 start -->
    <div id="content">
        <div class="typename">
        	<p></p>
            <h2><span><b>P</b>RODUCT</span><br/>业务种类</h2>
            <p></p>
        </div>
        <div class="list">
        	<?php 
                $dosql->Execute("SELECT * FROM `#@__infoclass` WHERE (id=5 OR parentstr LIKE '%,5,%') AND checkinfo=true ORDER BY orderid");
                while($row = $dosql->GetArray()){
                    if($row['id'] == $nid){$cla = 'act';}else{$cla = '';}
                   echo '<p><a class="'.$cla.'" href="article_product.php?cid=5&nid='.$row['id'].'">'.$row['classname'].'</a></p>';

                }
             ?>
        </div>
        <div class="product_body">
            <h2>光学仪器</h2>
            <div class="tuji">
                <script type="text/javascript" src="js/script.js"></script>
                <div id="tFocus">
                    <div class="prev" id="prev"></div>
                    <div class="next" id="next"></div>
                    <ul id="tFocus-pic">
            <?php
                $dopage->GetPage("SELECT * FROM `#@__infoimg` WHERE classid=$nid AND delstate='' AND checkinfo=true ORDER BY orderid DESC",8);
                while($row = $dosql->GetArray()){
                    if(isset($row['id']))
                    {
                        //获取链接地址
                        if($row['linkurl']=='' and $cfg_isreurl!='Y')
                            $gourl = 'article_product.php?cid=4&nid='.$row['classid'].'&id='.$row['id'];
                        else if($cfg_isreurl=='Y')
                            $gourl = 'article_product-'.$row['classid'].'-'.$row['id'].'-1.html';
                        else
                            $gourl = $row['linkurl'];
                        echo '<li><a href="'.$gourl.'"><img src="'.$row['picurl'].'" width="338" height="243" /></a></li>';
                    }
                    else
                    {
                        echo '网站资料更新中...';
                    }
                }
            ?>
                       
                    </ul>
                    <div id="tFocusBtn">
                        <a href="javascript:void(0);" id="tFocus-leftbtn">上一张</a>
                        <div id="tFocus-btn">
                            <ul>
                            <?php
                                $dopage->GetPage("SELECT * FROM `#@__infoimg` WHERE classid=$nid AND delstate='' AND checkinfo=true ORDER BY orderid DESC",8);
                                $i = 1;
                                while($row = $dosql->GetArray()){
                                    if(isset($row['id']))
                                    {
                                        if($i == 1){$cla = 'active';}else{$cla = '';}
                                        echo '<li class="'.$cla.'"><img src="'.$row['picurl'].'" width="87" height="57" /></li>';
                                    }
                                    else
                                    {
                                        echo '网站资料更新中...';
                                    }
                                    $i++;
                                }
                            ?>
                            </ul>
                        </div>
                        <a href="javascript:void(0);" id="tFocus-rightbtn">下一张</a>
                    </div>
                </div>
                <script type="text/javascript">addLoadEvent(Focus());</script>
            </div>
            <div class="cont">
                <h3>详细介绍</h3>
                <p>酒店尽占临海地利，828间客房的每扇偌大窗户，仿如宽阔大银幕，全日播映不同角度的维港醉人景致，为香港旅游住宿的必然首选。另有七层共202间贵宾客房，无论客人来香 港旅游住宿抑或商务住宿，我们都能全面满足不同人士的需要。</p><br/>
                <p>酒店尽占临海地利，828间客房的每扇偌大窗户，仿如宽阔大银幕，全日播映不同角度的维港醉人景致，为香港旅游住宿的必然首选。当中的122间套房及客房，设有现代化的小厨房，让长住酒店的宾客享受烹调的乐趣及方便。另有七层共202间贵宾客房，特别提供个人化服务，无论客人来香 港旅游住宿抑或商务住宿，我们都能全面满足不同人士的需要。酒店尽占临海地利，828间客房的每扇偌大窗户，仿如宽阔大银幕，全日播映不同角度的维港醉人景致，为香港旅游住宿的必然首选。当中的122间套房及客房，设有现代化的小厨房，让长住酒店的宾客享受烹调的乐趣及方便。另有七层共202间贵宾客房，特别提供个人化服务，无论客人来香 港旅游住宿抑或商务住宿，我们都能全面满足不同人士的需要。</p><br/>
                <p>酒店尽占临海地利，828间客房的每扇偌大窗户，仿如宽阔大银幕，全日播映不同角度的维港醉人景致，为香港旅游住宿的必然首选。另有七层共202间贵宾客房，无论客人来香 港旅游住宿抑或商务住宿，我们都能全面满足不同人士的需要。</p>
            </div>
        </div>
        <div id="shang">
            <p class="pre"><span>上一篇：</span><a href="article_product.html">体验诊断</a></p>
            <p class="next"><span>下一篇：</span><a href="article_product.html">检验设备</a></p>
        </div>
    </div>
    <!-- 供应产品 end -->
    <!-- 供应产品 end -->
	
	<!-- 公用底部 start -->
    <?php require_once('footer.php'); ?>
</body>
</html>