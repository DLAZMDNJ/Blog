<div class="footer">
	<div class="copyRight"><?php echo $cfg_copyright; ?></div>
	<div class="topBtn"><a href="#"></a></div>
</div>
