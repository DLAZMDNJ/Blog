<?php	require_once(dirname(__FILE__).'/inc/config.inc.php');

header('location:default.php');
exit();

?>
