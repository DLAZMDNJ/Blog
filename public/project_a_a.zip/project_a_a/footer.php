
<!-- 公用底部 start -->
<div id="foot">
    <div class="footer">
    	<?php echo $cfg_copyright ?><span>技术支持：<a href="http://www.ywvx.com/">亦网科技</a></span>
    </div>
</div>
    <!-- 公用底部 end -->
    <a href="#top" id="gotop"></a>
<!-- /weblink-->
<!-- footer-->
<!-- /footer-->
<?php

echo GetQQ();

//将流量统计代码放在页面最底部
$cfg_countcode;

?>