;!function(win){

//全局配置，如果采用默认均不需要改动
var config =  {
    path: 'a06fd2', //皮肤
	split_flag:'/'
};
var Lshd = {}, doc = document, creat = 'createElement', byid = 'getElementById', tags = 'getElementsByTagName';
var as = ['style.css'];

//获取存放路径
Lshd.getPath = (function(){
    return config.path;
}());
//获取分隔符
Lshd.getsp = (function(){
    return config.split_flag;
}());
//use
Lshd.use = function(lib, id){
    var link = doc[creat]('link');
    link.type = 'text/css';
    link.rel = 'stylesheet';
	if(lib !=""){
		link.href = Lshd.getPath + Lshd.getsp + lib + id;
		}else{
			link.href = Lshd.getPath + Lshd.getsp  + id;
		}
    
    id && (link.id = id);
    doc[tags]('head')[0].appendChild(link);
    link = null;
};

Lshd.init = (function(){
for (var i = 0; i < as.length; i++) {
		  Lshd.use('', as[i]);

    };
}());
}(window);