<?php require_once(dirname(__FILE__).'/include/config.inc.php');
$cid = empty($cid) ? 5 : intval($cid);
$nid = empty($nid) ? 5 : intval($nid);

 ?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="X-UA-Compatible" content="IE=Edge,chrome=1" />
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>某某医疗有限公司</title>
<meta content="网站关键字" name="keywords" />
<meta content="网站描述" name="description" />
<script type="text/javascript" src="global.js"></script>
<style type="text/css">
    .page_list a {
        display: inline-block;
        vertical-align: middle;
        margin: 0 4px;
        height: 28px;
        line-height: 28px;
        padding: 0 10px;
        border: 1px solid #ccc;
        color: #838383;
    }
    .page_list a:hover{
        background:#25B99F;
        color:#fff;
        border: 1px solid #fff;

    }
</style>
</head>
<body>
    <!-- 公用头部 start -->
    <!-- 导航 start -->
 <?php require_once('header.php'); ?>

	<!-- banner end -->
	<!-- 公用头部 end -->
        
    <!-- 供应产品 start -->
    <div id="content">
        <div class="typename">
        	<p></p>
            <h2><span><b>P</b>RODUCT</span><br/>业务种类</h2>
            <p></p>
        </div>
        <div class="list">
        	<?php 
                $dosql->Execute("SELECT * FROM `#@__infoclass` WHERE (id=5 OR parentstr LIKE '%,5,%') AND checkinfo=true ORDER BY orderid");
                while($row = $dosql->GetArray()){
                    if($row['id'] == $nid){$cla = 'act';}else{$cla = '';}
                   echo '<p><a class="'.$cla.'" href="product.php?cid=5&nid='.$row['id'].'">'.$row['classname'].'</a></p>';

                }
             ?>
        </div>
        <div class="product_body">
              <?php
                $dopage->GetPage("SELECT * FROM `#@__infoimg` WHERE classid=$nid AND delstate='' AND checkinfo=true ORDER BY orderid DESC",8);
                $i = 0;
                while($row = $dosql->GetArray()){
                    $i++;
                    if(isset($row['id']))
                    {
                        //获取链接地址
                        if($row['linkurl']=='' and $cfg_isreurl!='Y')
                            $gourl = 'article_product.php?cid='.$cid.'&nid='.$row['classid'].'&id='.$row['id'];
                        else if($cfg_isreurl=='Y')
                            $gourl = 'article_product-'.$row['classid'].'-'.$row['id'].'-1.html';
                        else
                            $gourl = $row['linkurl'];
                        if($i%4==0){$cla = 'style="margin-right:0px;"';}else{$cla = '';}
                        echo '<dl '.$cla.'>
                            <dt><a href="'.$gourl.'"><img src="'.$row['picurl'].'" alt="" /></a></dt>
                            <dd><a href="'.$gourl.'">'.ReStrLen($row['title'],10).'</a></dd>
                        </dl>';
                    }
                    else
                    {
                        echo '网站资料更新中...';
                    }
                }
            ?>
            
        </div>
        <ul id="page">
            <?php echo $dopage->GetList() ?>
        </ul>
    </div>
    <!-- 供应产品 end -->
	
	<!-- 公用底部 start -->
    <?php require_once('footer.php'); ?>
</body>
</html>