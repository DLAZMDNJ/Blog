<?php require_once(dirname(__FILE__).'/include/config.inc.php');
$cid = empty($cid) ? 4 : intval($cid);
$id  = empty($id)  ? 11 : intval($id);
$nid  = empty($nid)  ? 4 : intval($nid);
 ?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="X-UA-Compatible" content="IE=Edge,chrome=1" />
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>某某医疗有限公司</title>
<meta content="网站关键字" name="keywords" />
<meta content="网站描述" name="description" />
<script type="text/javascript" src="global.js"></script>
</head>
<body>
    <!-- 公用头部 start -->
    <!-- 导航 start -->
 <?php require_once('header.php'); ?>

	<!-- 公用头部 end -->
        
    <!-- 新闻动态 start -->
    <div id="content">
        <div class="typename">
        	<p></p>
            <h2><span><b>N</b>EWS CENTER</span><br/>新闻动态</h2>
            <p></p>
        </div>
        <div class="list">
        	 <?php 
                $dosql->Execute("SELECT * FROM `#@__infoclass` WHERE (id=4 OR parentstr LIKE '%,4,%') AND checkinfo=true ORDER BY orderid");
                while($row = $dosql->GetArray()){
                    if($row['id'] == $nid){$cla = 'act';}else{$cla = '';}
                   echo '<p><a class="'.$cla.'" href="news.php?cid=4&nid='.$row['id'].'">'.$row['classname'].'</a></p>';

                }
             ?>
        </div>
        <div class="news_body">
             <?php
                $dopage->GetPage("SELECT * FROM `#@__infolist` WHERE id=$id AND classid=$nid AND delstate='' AND checkinfo=true ORDER BY orderid DESC",10);
                    if($row = $dosql->GetArray())
                    {
                        //获取链接地址
                        if($cfg_isreurl != 'Y')
                            $gourl = 'newsshow.php?cid=4&nid='.$row['classid'].'&id='.$row['id'];
                        else
                            $gourl = 'newsshow-'.$row['classid'].'-'.$row['id'].'-1.html';
                        echo '<h2>'.$row['title'].'</h2>
                             <span class="pin">作者: '.$row['author'].' &nbsp;&nbsp; 发布时间: '.MyDate('m-d', $row['posttime']).' &nbsp;&nbsp; '.$row['hits'].' 次浏览</span>
                            <div class="cont">'.$row['content'].'</div>';
                    }else{
                        echo '网站资料更新中...';
                    }
            ?>
        </div>
        <div id="shang">
            <?php

                //获取上一篇信息
                $r = $dosql->GetOne("SELECT * FROM `#@__infolist` WHERE classid=".$nid." AND orderid>".$row['orderid']." AND delstate='' AND checkinfo=true ORDER BY orderid DESC");
                if($r < 1)
                {
                    echo '<p class="pre">上一篇：已经没有了</p>';
                }
                else
                {
                    if($cfg_isreurl != 'Y')
                        $gourl = 'newsshow.php?cid=4&nid='.$r['classid'].'&id='.$r['id'].'&oder='.$r['orderid'];
                    else
                        $gourl = 'newsshow-'.$r['classid'].'-'.$r['id'].'-1.html';

                    echo '<p class="pre"><span>上一篇：</span><a href="'.$gourl.'">'.ReStrLen($r['title'],20).'</a></p>';
                }
                
                //获取下一篇信息
                $r = $dosql->GetOne("SELECT * FROM `#@__infolist` WHERE classid=".$nid." AND orderid<".$row['orderid']." AND delstate='' AND checkinfo=true ORDER BY orderid ASC");
                if($r < 1)
                {
                    echo '<p class="next">下一篇：已经没有了</p>';
                }
                else
                {
                    if($cfg_isreurl != 'Y')
                        $gourl = 'newsshow.php?cid=4&nid='.$r['classid'].'&id='.$r['id'].'&oder='.$r['orderid'];
                    else
                        $gourl = 'newsshow-'.$r['classid'].'-'.$r['id'].'-1.html';

                    echo '<p class="next"><span>下一篇：</span><a href="'.$gourl.'">'.ReStrLen($r['title'],20).'</a></p>';
                }
                ?>
            
            
        </div>
    </div>
    <!-- 新闻动态 end -->
	
	<!-- 公用底部 start -->
    <?php require_once('footer.php'); ?>
</body>
</html>
