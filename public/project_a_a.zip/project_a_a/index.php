<?php require_once(dirname(__FILE__).'/include/config.inc.php');
$cid = empty($cid) ? 1 : intval($cid);
 ?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="X-UA-Compatible" content="IE=Edge,chrome=1" />
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>某某医疗有限公司</title>
<meta content="网站关键字" name="keywords" />
<meta content="网站描述" name="description" />
<script type="text/javascript" src="global.js"></script>
</head>
<body>
    <?php require_once('header.php'); ?>
            
    <div id="about">
    	<div class="title">
        	<h2>ABOUT US<span>关于我们</span></h2>
            <a href="list_about.html">+MORE</a>
        </div>
		<div class="cont">
    <!-- 首页关于我们 start -->
            <?php
                $row = $dosql->GetOne("SELECT * FROM `#@__info` WHERE classid=$cid");
                if(isset($row['id']))
                {
                   
                    echo $row['content'];
                }
                else
                {
                    echo '网站资料更新中...';
                }
            ?>
        </div>
    </div>
    <!-- 首页关于我们 end -->

	<!-- 首页团队 start -->
    <div id="team">
        <h2>THE ENTERPRISE CULTURE</h2>
        <p>提供百分之百满意的客户服务</p>
    </div>
    <!-- 首页团队 end -->

    <!-- 首页设备展示 start -->
    <div id="shebei">
    	<div class="title">
        	<h2>EQUIPMENT<span>设备展示</span></h2>
        </div>
		<div class="cont">
        	<div id="demo">
                <table border="0" cellpadding="1" cellspacing="1" cellspace="0" >
                    <tr>
                        <td valign=top id="marquePic1">
                            <table width='100%' border='0' cellspacing='0'>
                                <tr>
                                <?php
                                    $dosql->Execute("SELECT * FROM `#@__infoimg` WHERE classid=5 AND delstate='' AND checkinfo=true LIMIT 0,6");
                                    while($row = $dosql->GetArray())
                                    {
                                        if($row['picurl'] != ''){
                                            echo '<td><img src="'.$row['picurl'].'" alt="" ></td>';
                                        }
                                    }
                                    ?>
                                    
                                </tr>
                            </table>
                        </td>
                        <td id="marquePic2" valign=top></td>
                    </tr>
                </table>
            </div>

            <script type="text/javascript">
            var speed=40 
            marquePic2.innerHTML=marquePic1.innerHTML 
            function Marquee(){ 
            if(demo.scrollLeft>=marquePic1.scrollWidth){ 
            demo.scrollLeft=0 
            }else{ 
            demo.scrollLeft++ 
            } 
            } 
            var MyMar=setInterval(Marquee,speed) 
            demo.onmouseover=function() {clearInterval(MyMar)} 
            demo.onmouseout=function() {MyMar=setInterval(Marquee,speed)} 
            </script>
        </div>
    </div>
    <!-- 首页设备展示 start -->
	
    <!-- 首页新闻资讯 start -->
    <div id="news">
    	<div class="title">
        	<h2>NEWS<span>新闻资讯</span></h2>
            <a href="list_news.html">+MORE</a>
        </div>
        <div class="cont">
            <?php
                $dosql->Execute("SELECT * FROM `#@__infolist` WHERE classid=4 AND delstate='' AND checkinfo=true ORDER BY orderid DESC LIMIT 0,6");
                while($row = $dosql->GetArray()){
                    if(isset($row['id']))
                    {
                        //获取链接地址
                        if($row['linkurl']=='' and $cfg_isreurl!='Y')
                            $gourl = 'newsshow.php?cid='.$row['classid'].'&id='.$row['id'];
                        else if($cfg_isreurl=='Y')
                            $gourl = 'newsshow-'.$row['classid'].'-'.$row['id'].'-1.html';
                        else
                            $gourl = $row['linkurl'];

                        //获取缩略图地址
                        if($row['picurl']!=''){

                            echo '<dl>
                                <dt><a href="article_news.html"><img src="'.$row['picurl'].'" alt="" /></a></dt>
                                <dd class="tit"><a href="article_news.html">'.ReStrLen($row['title'],15).'</a></dd>
                                <dd class="con">'.ReStrLen($row['content'],60).'<a href="'.$gourl.'">【更多】​</a></dd>
                            </dl><ul>';
                        }

                            echo '<li><a href="'.$gourl.'">'.ReStrLen($row['title'],15).'</a><span>'.MyDate('m-d', $row['posttime']).'</span></li>';
                            
                    }
                    else
                    {
                        echo '网站资料更新中...';
                    }
                }
            ?>
                            	
            
            </ul>
        </div>
    </div>
    <!-- 首页新闻资讯 end -->
    
    <!-- 首页产品展示 start -->
    <div id="product">
    	<div class="title">
        	<h2>EQUIPMENT<span>设备展示</span></h2>
        </div>
		<div class="cont">
            <?php
                $dosql->Execute("SELECT * FROM `#@__infoimg` WHERE classid=5 AND delstate='' AND checkinfo=true ORDER BY orderid DESC LIMIT 0,8");
                $a = 0;
                while($row = $dosql->GetArray())
                {
                    $a++;
                    if($a%4==0){$mar = 'margin-right:0px;';}else{$mar = '';}
                    //获取链接地址
                    if($row['linkurl']=='' and $cfg_isreurl!='Y')
                        $gourl = 'productshow.php?cid='.$row['classid'].'&id='.$row['id'];
                    else if($cfg_isreurl=='Y')
                        $gourl = 'productshow-'.$row['classid'].'-'.$row['id'].'-1.html';
                    else
                        $gourl = $row['linkurl'];

                    //获取缩略图地址
                    if($row['picurl']!='')
                        $picurl = $row['picurl'];
                    else
                        $picurl = 'templates/default/images/nofoundpic.gif';
                    echo '<dl style="'.$mar.'">
                            <dt><a href="'.$gourl.'"><img src="'.$picurl.'" alt="" /></a></dt>
                            <dd><a href="'.$gourl.'">'.$row['title'].'</a></dd>
                        </dl>';
                }
                ?>
        </div>
    </div>
    <!-- 首页产品展示 start -->
    
	<?php require_once('footer.php'); ?>
</body>
</html>