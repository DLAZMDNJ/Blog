<?php require_once(dirname(__FILE__).'/include/config.inc.php');
$cid = empty($cid) ? 14 : intval($cid);
//留言内容处理
if(isset($action) and $action=='add')
{
    if(empty($contact) or
       empty($content))
    {
        header('location:message.php');
        exit();
    }
    
    
    //检测数据正确性
        if(empty($nickname)){$nickname = '游客';}
        $r = $dosql->GetOne("SELECT Max(orderid) AS orderid FROM `#@__message`");
        $orderid  = (empty($r['orderid']) ? 1 : ($r['orderid'] + 1));
        $nickname = htmlspecialchars($nickname);
        $contact  = htmlspecialchars($contact);
        $content  = htmlspecialchars($content);
        $posttime = GetMkTime(time());
        $ip       = gethostbyname($_SERVER['REMOTE_ADDR']);
    
    
        $sql = "INSERT INTO `#@__message` (siteid, nickname, contact, content, orderid, posttime, htop, rtop, checkinfo, ip) VALUES (1, '$nickname', '$contact', '$content', '$orderid', '$posttime', '', '', 'false', '$ip')";
        if($dosql->ExecNoneQuery($sql))
        {
            ShowMsg('留言成功，感谢您的支持！','message.php');
            exit();
        }
}
 ?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="X-UA-Compatible" content="IE=Edge,chrome=1" />
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>某某医疗有限公司</title>
<meta content="网站关键字" name="keywords" />
<meta content="网站描述" name="description" />
<style type="text/css">
    .msg_input_on {
        width: 590px;
        height: 32px;
        line-height: 32px;
        border: 1px dashed #AAA;
        background: #f1f9ff;
        padding-left: 10px;
        -webkit-box-shadow: 0px 2px 0px 0px rgba(0, 0, 0, 0.03);
        box-shadow: 0px 2px 0px 0px rgba(0, 0, 0, 0.03);
        border-radius: 2px;
        font-size: 14px;
        color: #888;
        outline: none;
    }
    .msg_input{
        max-width: 580px;
        min-height: 100px;
        width: 580px;
        height: 100px;
        line-height: 30px;
        border: 1px dashed #AAA;
        background: #f1f9ff;
        padding: 10px;
        -webkit-box-shadow: 0px 2px 0px 0px rgba(0, 0, 0, 0.03);
        box-shadow: 0px 2px 0px 0px rgba(0, 0, 0, 0.03);
        border-radius: 2px;
        font-size: 14px;
        color: #888;
        outline: none;
    }
    
</style>
<script type="text/javascript" src="global.js"></script>
<script type="text/javascript" src="templates/default/js/jquery.min.js"></script>
<script type="text/javascript">
function cfm_msg()
{
    if($('#form').find('input').eq(1).val() == "")
    {
        alert("请填写联系方式！");
        $('#form').find('input').eq(1).focus();
        return false;
    }
    if($('#form').find('input').eq(3).val() == "")
    {
        alert("请填写留言内容！");
        $('#form').find('input').eq(3).focus();
        return false;
    }
    $("#form").submit();
}

$(function(){
    $('#form').find('input').each(function(){
        $(this).focus(function(){
            $(this).attr("class", 'msg_input_on');
        }).blur(function(){
            $(this).attr("class", 'text');
        });
    })
    $('#form').find('textarea').each(function(){
        $(this).focus(function(){
            $(this).attr("class", 'msg_input');
        }).blur(function(){
            $(this).attr("class", 'mess');
        });
    })

    $("#form").find('input').eq(0).focus();
});
</script>
</head>
<body>
    <!-- 公用头部 start -->
    <!-- 导航 start -->
 <?php require_once('header.php'); ?>

	<!-- banner end -->
	<!-- 公用头部 end -->
        
    <!-- 公司简介 start -->
    <div id="content">
        <div class="typename">
        	<p></p>
            <h2><span><b>M</b>ESSAGE</span><br/>用户留言</h2>
            <p></p>
        </div>
        <div class="mess_body">
            <h2>您的意见和建议对我们非常重要，请帮助我们，让我们变得更好！</h2>
            <form name="form" id="form" method="post" action="">
                <p>您的姓名</p>
                <input class="text" type="text" name="nickname"/>
                <p>联系方式</p>
                <input class="text" type="text" name="contact"/>
                <p>留言标题</p>
                <input class="text" type="text" name="title"/>
                <p>留言内容</p>
                <textarea class="mess" name="content" cols="" rows="" ></textarea><br/>
                <input type="hidden" name="action" id="action" value="add" />
                <button onclick="cfm_msg();return false;" class="sub">提交</button>
            </form>
        </div>
    </div>
    <!-- 公司简介 end -->
	
	<!-- 公用底部 start -->
    <?php require_once('footer.php'); ?>
</body>
</html>