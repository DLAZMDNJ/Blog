<?php require_once(dirname(__FILE__).'/include/config.inc.php');
$cid = empty($cid) ? 4 : intval($cid);
$nid = empty($nid) ? 4 : intval($nid);
 ?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="X-UA-Compatible" content="IE=Edge,chrome=1" />
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>某某医疗有限公司</title>
<meta content="网站关键字" name="keywords" />
<meta content="网站描述" name="description" />
<script type="text/javascript" src="global.js"></script>
</head>
<body>
    <!-- 公用头部 start -->
    <!-- 导航 start -->
 <?php require_once('header.php'); ?>

	<!-- banner end -->
	<!-- 公用头部 end -->
        
    <!-- 新闻动态 start -->
    <div id="content">
        <div class="typename">
        	<p></p>
            <h2><span><b>N</b>EWS CENTER</span><br/>新闻动态</h2>
            <p></p>
        </div>
        <div class="list">
            <?php 
                $dosql->Execute("SELECT * FROM `#@__infoclass` WHERE (id=4 OR parentstr LIKE '%,4,%') AND checkinfo=true ORDER BY orderid");
                while($row = $dosql->GetArray()){
                    if($row['id'] == $nid){$cla = 'act';}else{$cla = '';}
        	       echo '<p><a class="'.$cla.'" href="news.php?cid=4&nid='.$row['id'].'">'.$row['classname'].'</a></p>';

                }
             ?>
        </div>
        <ul class="news_body">
        <?php
                $dopage->GetPage("SELECT * FROM `#@__infolist` WHERE classid=$nid AND delstate='' AND checkinfo=true ORDER BY orderid DESC",10);
                while($row = $dosql->GetArray()){
                    if(isset($row['id']))
                    {
                        //获取链接地址
                        if($row['linkurl']=='' and $cfg_isreurl!='Y')
                            $gourl = 'newsshow.php?cid=4&nid='.$row['classid'].'&id='.$row['id'];
                        else if($cfg_isreurl=='Y')
                            $gourl = 'newsshow-'.$row['classid'].'-'.$row['id'].'-1.html';
                        else
                            $gourl = $row['linkurl'];
    
                        echo '<li><a href="'.$gourl.'">'.ReStrLen($row['title'],80).'</a><span>'.MyDate('m-d', $row['posttime']).'</span></li>';
                    }
                    else
                    {
                        echo '网站资料更新中...';
                    }
                }
            ?>
            
        </ul>
        <ul id="page">
            <?php echo $dopage->GetList() ?>
        </ul>
    </div>
    <!-- 新闻动态 end -->
	
	<!-- 公用底部 start -->
   <?php require_once('footer.php'); ?>
</body>
</html>