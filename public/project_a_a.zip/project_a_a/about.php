<?php require_once(dirname(__FILE__).'/include/config.inc.php');
$cid = empty($cid) ? 2 : intval($cid);
 ?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="X-UA-Compatible" content="IE=Edge,chrome=1" />
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>某某医疗有限公司</title>
<meta content="网站关键字" name="keywords" />
<meta content="网站描述" name="description" />
<script type="text/javascript" src="global.js"></script>
</head>
<body>
    <!-- 公用头部 start -->
    <!-- 导航 start -->
 <?php require_once('header.php'); ?>
    
	<!-- 公用头部 end -->
        
    <!-- 关于我们 start -->
    <div id="content">
        <div class="typename">
        	<p></p>
            <h2><span>ABOUT US</span><br/>关于我们</h2>
            <p></p>
        </div>
        <div class="about_body">
             <?php
                $row = $dosql->GetOne("SELECT * FROM `#@__info` WHERE classid=$cid");
                if(isset($row['id']))
                {
                   
                    echo $row['content'];
                }
                else
                {
                    echo '网站资料更新中...';
                }
            ?>
        </div>
        <!-- 设备展示 start -->
    	<div id="shebei">
            <div class="title">
                <h2>EQUIPMENT<span>设备展示</span></h2>
            </div>
            <div class="cont">
                <div id="demo">
                    <table border='0' cellpadding='1' cellspacing='1' cellspace='0' >
                        <tr>
                            <td valign=top id='marquePic1'>
                                <table width='100%' border='0' cellspacing='0'>
                                    <tr>
                                        <?php
                                            $dosql->Execute("SELECT * FROM `#@__infoimg` WHERE classid=5 AND delstate='' AND checkinfo=true LIMIT 0,6");
                                            while($row = $dosql->GetArray())
                                            {
                                                if($row['picurl'] != ''){
                                                    echo '<td><img src="'.$row['picurl'].'" alt="" ></td>';
                                                }
                                            }
                                        ?>
                                    </tr>
                                </table>
                            </td>
                            <td id='marquePic2' valign='top'></td>
                        </tr>
                    </table>
                </div>
                <script type="text/javascript">
                var speed=40 
                marquePic2.innerHTML=marquePic1.innerHTML 
                function Marquee(){ 
                if(demo.scrollLeft>=marquePic1.scrollWidth){ 
                demo.scrollLeft=0 
                }else{ 
                demo.scrollLeft++ 
                } 
                } 
                var MyMar=setInterval(Marquee,speed) 
                demo.onmouseover=function() {clearInterval(MyMar)} 
                demo.onmouseout=function() {MyMar=setInterval(Marquee,speed)} 
                </script>
            </div>
        </div>
    	<!-- 设备展示 start -->
    </div>
    <!-- 公司简介 end -->
	
	<!-- 公用底部 start -->
    <?php require_once('footer.php'); ?>
</body>
</html>