    <a name="top"></a>
	<!-- 公用头部 start -->
    <!-- 导航 start -->
    <div id="wei">
        <div id="nav">
            <a class="logo" href="index.php"><img src="images/logo.png" alt="" /></a>
            <ul>
                <?php echo GetNav(); ?>
            </ul>
        </div>
    </div>
    <!-- 导航 end -->
    <!-- banner start -->
    <div id="banner">
        <?php 
            $row = $dosql->GetOne("SELECT picurl FROM `#@__infoclass` WHERE id=$cid");
            echo '<img src="'.$row['picurl'].'" alt="" />';
        ?>
    </div>
	<!-- banner end -->
	<!-- 公用头部 end -->