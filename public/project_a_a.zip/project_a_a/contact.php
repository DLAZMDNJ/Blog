<?php require_once(dirname(__FILE__).'/include/config.inc.php');
$cid = empty($cid) ? 9 : intval($cid);
 ?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="X-UA-Compatible" content="IE=Edge,chrome=1" />
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>某某医疗有限公司</title>
<meta content="网站关键字" name="keywords" />
<meta content="网站描述" name="description" />
<script type="text/javascript" src="global.js"></script>
<script type="text/javascript" src="http://api.map.baidu.com/api?v=2.0&ak=oMNyTFmnvwbFIWgR2MV7KV3c7KHcXP5B"></script>
</head>
<body>
    <!-- 公用头部 start -->
    <!-- 导航 start -->
 <?php require_once('header.php'); ?>

	<!-- banner end -->
	<!-- 公用头部 end -->
        
    <!-- 联系我们 start -->
    <div id="content">
        <div class="typename">
        	<p></p>
            <h2><span><b>C</b>ONTACT US</span><br/>联系我们</h2>
            <p></p>
        </div>
        <div class="contact_body">
            <div class="map" id='container'>
            	<img src="images/map.png" alt="" />
            </div>
            <div class="right">
            	<?php echo Info($cid); ?>
            </div>
        </div>
    </div>
    <!-- 联系我们 end -->
	
	<!-- 公用底部 start -->
    <?php require_once('footer.php'); ?>
    <script type="text/javascript">
        // 百度地图API功能
    var map = new BMap.Map("container");    // 创建Map实例
    var point = new BMap.Point(116.404, 39.915);
    map.centerAndZoom(point, 15);  // 初始化地图,设置中心点坐标和地图级别
    map.addControl(new BMap.MapTypeControl());   //添加地图类型控件
    map.setCurrentCity("北京");          // 设置地图显示的城市 此项是必须设置的
    map.enableScrollWheelZoom(true);     //开启鼠标滚轮缩放


    var top_left_control = new BMap.ScaleControl({anchor: BMAP_ANCHOR_TOP_LEFT});// 左上角，添加比例尺
    var top_left_navigation = new BMap.NavigationControl();  //左上角，添加默认缩放平移控件
    //添加控件和比例尺
        map.addControl(top_left_control);        
        map.addControl(top_left_navigation);   
    </script>
</body>
</html>